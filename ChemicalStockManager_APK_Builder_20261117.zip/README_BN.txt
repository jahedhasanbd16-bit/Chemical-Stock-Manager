Chemical Stock Manager - Android project
========================================

এই প্রজেক্ট দিয়ে GitHub Actions ব্যবহার করে Android APK তৈরি করা যাবে।

APK এখনো তৈরি করা নেই। GitHub-এ repository তৈরি করে এই ZIP-এর ভেতরের সব ফাইল আপলোড করুন।
বিশেষভাবে .github/workflows/android.yml ফাইলটিও আপলোড হতে হবে।

GitHub-এ ফাইল আপলোডের পর Actions ট্যাবে গিয়ে workflow চালু/সম্পন্ন হতে দিন।
সফল হলে workflow run-এর Artifacts অংশ থেকে ChemicalStockManager-debug-apk ডাউনলোড করুন।
ZIP extract করলে app-debug.apk পাবেন।

Android-এ APK ইনস্টল করার সময় প্রয়োজন হলে browser/file manager-এর জন্য Install unknown apps অনুমতি দিন।
